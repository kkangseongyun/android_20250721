package com.example.tripapp.network;

public class News {
    long id;
    String author;
    String title;
    String description;
    String urlToImage;
    String publishedAt;
}
